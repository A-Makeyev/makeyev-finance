import type { Page } from '@playwright/test'
import { test, expect, seedLanguage, seedSiteState } from '../../fixtures'
import { HOVER_CLOSE_DELAY_MS, PANEL_EXIT_DURATION_MS } from '@/lib/timings'

/**
 * The calculator's inline "?" help tooltips: a toggle tip per tooltip must
 * open on click/tap AND from the keyboard (Enter/Space on the focused icon),
 * close on Escape, outside press and on navigation, announce themselves
 * (aria-expanded + aria-describedby) and never overflow the viewport at phone
 * width - the same clamp the chart tooltips get from useTooltipClamp. Checked
 * in both languages (the icon flips sides with the direction) and both themes
 * (the panel uses the calculator's theme-aware tokens).
 */

const VIEWPORTS = [
  { width: 360, height: 800, tag: '360' },
  { width: 1280, height: 900, tag: '1280' },
]

/** Each tooltip's icon and where its "read more" link should lead. */
const TOOLTIPS: Array<{ icon: string; linkHref: RegExp }> = [
  { icon: 'help-track-type-1', linkHref: /\/articles\/mortgage-track-types$/ },
  { icon: 'help-method-1', linkHref: /\/articles\/mortgage-decisions$/ },
  { icon: 'help-term', linkHref: /\/articles\/mortgage-track-types$/ },
  { icon: 'help-preset', linkHref: /\/articles\/mortgage-decisions$/ },
]

async function assertPanelInsideViewport(page: Page): Promise<void> {
  const rect = (await page.evaluate(`(() => {
    const r = document.querySelector('.help-tooltip-panel').getBoundingClientRect();
    return { left: r.left, right: r.right, innerWidth: window.innerWidth };
  })()`)) as { left: number; right: number; innerWidth: number }
  expect(rect.left, 'panel left edge').toBeGreaterThanOrEqual(0)
  expect(rect.right, 'panel right edge').toBeLessThanOrEqual(rect.innerWidth)
  // The page clips root overflow-x, so horizontal overflow would be silent -
  // measure it instead of trusting the screenshot.
  const overflow = (await page.evaluate(
    'document.documentElement.scrollWidth - document.documentElement.clientWidth',
  )) as number
  expect(overflow, 'horizontal overflow').toBeLessThanOrEqual(1)
}

for (const language of ['hebrew', 'english'] as const) {
  for (const viewport of VIEWPORTS) {
    test(`calculator help tooltips - ${language} @ ${viewport.tag}px`, async ({ page }) => {
      await seedLanguage(page, language)
      await page.setViewportSize({ width: viewport.width, height: viewport.height })
      await page.goto('/calculators')

      for (const { icon, linkHref } of TOOLTIPS) {
        const trigger = page.getByTestId(icon)
        await expect(trigger).toBeVisible()
        await expect(trigger).toHaveAttribute('aria-expanded', 'false')

        // Click/tap opens the panel, wires the description to the icon and
        // shows the read-more link to the relevant article.
        await trigger.click()
        await expect(trigger).toHaveAttribute('aria-expanded', 'true')
        const panel = page.locator(`[data-testid="${icon}-panel"]`)
        await expect(panel).toBeVisible()
        // React 18 used ':r2:'; React 19 (the Next app) uses '_R_<hash>_' - accept both.
        await expect(trigger).toHaveAttribute('aria-describedby', /:r\d+:|_[rR]_[a-z0-9]+_|r\d+/)
        const readMore = panel.locator('a')
        await expect(readMore).toBeVisible()
        expect(await readMore.getAttribute('href')).toMatch(linkHref)

        // The panel must fit the viewport while open (the binding case at
        // 360px, checked on every tooltip since they sit at different edges).
        await assertPanelInsideViewport(page)

        // Escape closes; the outside press closes too. The outside press
        // targets the panel's own heading, far from the tooltip at any
        // viewport width (a raw viewport-corner click can land on the open
        // panel itself on a phone, which correctly does NOT close it). The
        // panel stays mounted, so closed means hidden, not removed.
        await page.keyboard.press('Escape')
        await expect(trigger).toHaveAttribute('aria-expanded', 'false')
        await expect(panel).toBeHidden()
        await trigger.click()
        await expect(panel).toBeVisible()
        await page.locator('.panel-heading h2').click()
        await expect(trigger).toHaveAttribute('aria-expanded', 'false')

        // Keyboard: Enter toggles open (Space does the same via the native
        // button), so hover is never the only way in.
        await trigger.focus()
        await page.keyboard.press('Enter')
        await expect(trigger).toHaveAttribute('aria-expanded', 'true')
        await expect(panel).toBeVisible()
        await page.keyboard.press('Enter')
        await expect(trigger).toHaveAttribute('aria-expanded', 'false')
      }
    })
  }
}

test('calculator help tooltip - hover opens, grace close, click pins', async ({ page }) => {
  // The grace close is a 300ms setTimeout in the component; racing it with
  // wall-clock waits was flaky under CI load (the assert-after-120ms could
  // land after the timer fired). Installing the clock before navigation puts
  // the component's timers on the virtual clock: 0ms have elapsed while we
  // assert "still open", and fastForward fires the close deterministically.
  await page.clock.install()
  await seedLanguage(page, 'hebrew')
  await page.setViewportSize({ width: 1280, height: 900 })
  await page.goto('/calculators')

  const trigger = page.getByTestId('help-method-1')
  const closedBorder = (await page.evaluate(
    `getComputedStyle(document.querySelector('[data-testid="help-method-1"]')).borderColor`,
  )) as string

  // Hovering the icon opens the panel.
  await trigger.hover()
  let panel = page.getByTestId('help-method-1-panel')
  await expect(panel).toBeVisible()

  // Moving the pointer onto the read-more link keeps the panel open (grace
  // close + bridge), and the link is really clickable. One direct move to the
  // link's center, not a pixel path across the gap: the path's intermediate
  // points are load-sensitive and flaked in the full suite, while the behavior
  // under test (the grace close is NOT triggered once the pointer lands on the
  // panel's link) is identical. Playwright's own hover() is avoided here
  // because its stability wait needs rAF frames, and the virtual clock below
  // never lets them advance - it retried until the panel had re-rendered.
  const link = panel.locator('a')
  // Move + check are retried as ONE step: under parallel-suite load the
  // widget's DOM node can be replaced (a late hydration re-render) while the
  // pointer is on its way, which detaches the node the move was aimed at.
  // Retrying re-resolves the link on the live panel; the behavior under test
  // (the grace close is NOT triggered once the pointer lands on the link) is
  // unchanged, and the virtual clock below cannot close the panel meanwhile.
  await expect(async () => {
    const box = (await link.boundingBox())!
    await page.mouse.move(box.x + box.width / 2, box.y + box.height / 2)
    await expect(panel).toBeVisible()
  }).toPass({ timeout: 20_000 })
  await page.mouse.down()
  await page.mouse.up()
  await expect(page).toHaveURL(/\/articles\/mortgage-decisions$/)

  // Back on the calculator: leaving the widget closes the hover-open panel
  // after the grace period (not instantly - jitter must not flap it).
  await page.goBack()
  await expect(page).toHaveURL(/\/calculators$/)
  await trigger.hover()
  panel = page.getByTestId('help-method-1-panel')
  await expect(panel).toBeVisible()
  await page.mouse.move(20, 20)
  // No virtual time has passed since the pointer left, so the 300ms grace
  // timer has not fired: the panel must still be open and the trigger styled.
  await expect(panel, 'still open within the grace window').toBeVisible()
  const graceBorder = (await page.evaluate(
    `getComputedStyle(document.querySelector('[data-testid="help-method-1"]')).borderColor`,
  )) as string
  expect(graceBorder, 'trigger stays styled while the panel is closing').not.toBe(closedBorder)
  // Fire the grace timer: the panel closes (150ms exit animation follows).
  await page.clock.fastForward(HOVER_CLOSE_DELAY_MS + PANEL_EXIT_DURATION_MS)
  await expect(trigger).toHaveAttribute('aria-expanded', 'false')
  await expect(panel).toHaveCount(0)

  // Clicking pins the panel against hover-out: the pointer can go anywhere,
  // the panel stays; only another click closes it.
  await trigger.click()
  panel = page.getByTestId('help-method-1-panel')
  await expect(panel).toBeVisible()
  await page.mouse.move(20, 20)
  // Pinned ignores hover-out entirely, real or virtual time - the pointer
  // moving away must not close it at any point.
  await page.clock.fastForward(HOVER_CLOSE_DELAY_MS + PANEL_EXIT_DURATION_MS)
  await expect(panel, 'pinned panel survives hover-out').toBeVisible()
  await trigger.click()
  await expect(trigger).toHaveAttribute('aria-expanded', 'false')
  await expect(panel).toHaveCount(0)
})

test('calculator help tooltip - the "?" stays on the label line', async ({ page }) => {
  for (const viewport of [360, 1280] as const) {
    await seedLanguage(page, 'hebrew')
    await page.setViewportSize({ width: viewport, height: 800 })
    await page.goto('/calculators')

    // For every tooltip: the icon must vertically overlap its label text. If
    // the icon wrapped to its own line below the text (the narrow-grid
    // regression), the icon's top edge would sit at or below the text's
    // bottom edge. When the text itself wraps to two lines the icon sits
    // beside the block, which still overlaps - that is fine.
    const overlaps = (await page.evaluate(`(() => {
      const ids = ['help-track-type-1', 'help-method-1', 'help-term', 'help-preset'];
      return ids.map((id) => {
        const icon = document.querySelector('[data-testid="' + id + '"]');
        const text = icon.closest('.label-help-row').querySelector('.label-help-text');
        const i = icon.getBoundingClientRect();
        const t = text.getBoundingClientRect();
        return { id, overlap: i.top < t.bottom - 1 && i.bottom > t.top + 1 };
      });
    })()`)) as Array<{ id: string; overlap: boolean }>
    for (const { id, overlap } of overlaps) {
      expect(overlap, `${id} icon on the label line @ ${viewport}px`).toBe(true)
    }
  }
})

test('calculator help tooltip - near does nothing, over the icon opens and recolors', async ({
  page,
}) => {
  await seedLanguage(page, 'hebrew')
  await page.setViewportSize({ width: 1280, height: 900 })
  await page.goto('/calculators')

  const trigger = page.getByTestId('help-method-1')
  const labelText = trigger.evaluate((icon) =>
    icon.closest('.label-help-row')!.querySelector('.label-help-text')!.getBoundingClientRect(),
  )

  // Hover NEAR: over the neighbouring label text, right next to the icon.
  // Nothing opens and the icon's border stays gray.
  const textRect = await labelText
  await page.mouse.move(textRect.x + textRect.width - 4, textRect.y + textRect.height / 2)
  await page.waitForTimeout(200)
  await expect(page.getByTestId('help-method-1-panel')).toHaveCount(0)
  const nearBorder = (await page.evaluate(
    `getComputedStyle(document.querySelector('[data-testid="help-method-1"]')).borderColor`,
  )) as string

  // Hover OVER the icon: the text shows AND the border turns teal.
  await trigger.hover()
  const panel = page.getByTestId('help-method-1-panel')
  await expect(panel).toBeVisible()
  const overBorder = (await page.evaluate(
    `getComputedStyle(document.querySelector('[data-testid="help-method-1"]')).borderColor`,
  )) as string
  expect(overBorder, 'border recolors only over the icon').not.toBe(nearBorder)

  // Sweep across the label (near, not over) while open: the open panel and
  // the styling are untouched by proximity - gray returns only off the icon.
  await page.mouse.move(textRect.x + 4, textRect.y + textRect.height / 2)
  await expect(panel, 'panel survives passing near the icon').toBeVisible()
})

test('calculator help tooltip - the label never forwards hover/click to the "?" icon', async ({
  page,
}) => {
  // Regression: each tooltip sits inside a <label>. When the label's implicit
  // control was the tooltip's own "?" button (first labelable descendant),
  // Chrome extended the button's :hover and click activation across the whole
  // label text - the icon's border recolored teal with the cursor far from
  // it, and clicking the label text toggled the panel. Labels now bind to
  // their real control via htmlFor, so the phantom zone is gone.
  await seedLanguage(page, 'hebrew')
  await page.setViewportSize({ width: 1280, height: 900 })
  await page.goto('/calculators')
  // Wait for the app to mount before probing the DOM (a raw evaluate does
  // not auto-wait, and the loading screen delays the form).
  await page.waitForSelector('[data-testid="help-term"]')

  // Every label hosting a tooltip must point at a control that is NOT the
  // tooltip's own trigger button. Catches the bug structurally, at any
  // viewport or DOM order.
  const wrongControls = (await page.evaluate(`(() => {
    const bad = [];
    for (const row of document.querySelectorAll('.label-help-row')) {
      const label = row.closest('label');
      if (!label) continue;
      const trigger = row.querySelector('.help-tooltip-trigger');
      if (label.control && trigger && label.control === trigger) {
        bad.push(label.className);
      }
    }
    return bad;
  })()`)) as string[]
  expect(wrongControls, 'tooltip labels bound to their own "?" button').toEqual([])

  // Behavioral check on the term tooltip (the reported one): sweep the whole
  // label text - the icon must never :hover or recolor from a distance, and
  // clicking the text must not open the panel.
  const termText = page.locator('label.term-slider .label-help-row .label-help-text').first()
  await termText.scrollIntoViewIfNeeded()
  const box = await termText.boundingBox()
  expect(box, 'term label text is visible').not.toBeNull()

  const sweep = async (yOffset: number) => {
    for (let step = 0; step <= 8; step++) {
      const x = box!.x + (box!.width * step) / 8
      const y = box!.y + box!.height / 2 + yOffset
      await page.mouse.move(x, y)
      await page.waitForTimeout(40)
      const state = (await page.evaluate(`(() => {
        const btn = document.querySelector('[data-testid="help-term"]');
        return { hover: btn.matches(':hover'), open: !!document.querySelector('[data-testid="help-term-panel"]') };
      })()`)) as { hover: boolean; open: boolean }
      expect(
        state.hover,
        `icon not :hover at ${Math.round((step / 8) * 100)}% of label width`,
      ).toBe(false)
      expect(state.open, `panel closed at ${Math.round((step / 8) * 100)}% of label width`).toBe(
        false,
      )
    }
  }
  await sweep(0)

  // Clicks along the text must not toggle the tooltip either (they land on
  // the label, whose control is the slider - a no-op for value).
  await page.mouse.click(box!.x + box!.width / 2, box!.y + box!.height / 2)
  await page.waitForTimeout(150)
  await expect(page.getByTestId('help-term-panel')).toHaveCount(0)

  // Just below the text row (still inside the label, over the slider area):
  // same assertions.
  await sweep(box!.height)

  // Sanity: the icon itself still works - hover recolors and opens.
  await page.getByTestId('help-term').hover()
  await expect(page.getByTestId('help-term-panel')).toBeVisible()
})

test('calculator help tooltip - the panel uses the theme tokens in dark mode', async ({ page }) => {
  await seedSiteState(page, { language: 'hebrew', theme: 'dark' })
  await page.setViewportSize({ width: 360, height: 800 })
  await page.goto('/calculators')

  const trigger = page.getByTestId('help-track-type-1')
  await trigger.click()
  const panel = page.getByTestId('help-track-type-1-panel')
  await expect(panel).toBeVisible()
  await expect(page.locator('html')).toHaveAttribute('data-theme', 'dark')

  const colors = (await page.evaluate(`(() => {
    const cs = getComputedStyle(document.querySelector('.help-tooltip-panel'));
    return { bg: cs.backgroundColor, ink: cs.color };
  })()`)) as { bg: string; ink: string }
  const channelsOf = (rgb: string) =>
    rgb
      .replace(/[^0-9,]/g, '')
      .split(',')
      .slice(0, 3)
      .map(Number)
  for (const channel of channelsOf(colors.bg)) expect(channel, 'panel fill').toBeLessThan(60)
  for (const channel of channelsOf(colors.ink)) expect(channel, 'panel ink').toBeGreaterThan(150)
})
